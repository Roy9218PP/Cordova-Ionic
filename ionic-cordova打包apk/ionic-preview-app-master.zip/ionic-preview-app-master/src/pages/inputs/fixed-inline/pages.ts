import { Component } from '@angular/core';


@Component({
  templateUrl: 'template.html'
})
export class FixedInlinePage { }
