import { Component } from '@angular/core';


@Component({
  templateUrl: 'full.html'
})
export class FullPage { }
