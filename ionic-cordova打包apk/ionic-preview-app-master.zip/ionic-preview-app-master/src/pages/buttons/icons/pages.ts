import { Component } from '@angular/core';


@Component({
  templateUrl: 'icons.html'
})
export class IconsPage { }
