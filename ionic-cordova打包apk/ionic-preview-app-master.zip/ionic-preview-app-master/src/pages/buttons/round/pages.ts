import { Component } from '@angular/core';


@Component({
  templateUrl: 'round.html'
})
export class RoundPage { }
