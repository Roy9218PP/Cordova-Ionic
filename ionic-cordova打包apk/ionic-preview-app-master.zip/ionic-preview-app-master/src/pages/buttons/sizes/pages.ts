import { Component } from '@angular/core';


@Component({
  templateUrl: 'sizes.html'
})
export class SizesPage { }
