import { Component } from '@angular/core';


@Component({
  templateUrl: 'basic.html'
})
export class BasicPage { }
