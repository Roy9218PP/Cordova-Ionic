import { Component } from '@angular/core';


@Component({
  templateUrl: 'components.html'
})
export class ComponentsPage { }
